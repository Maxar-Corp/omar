package de.andreasschmitt.richui.taglib.renderer

import org.codehaus.groovy.grails.commons.ConfigurationHolder

class YuiUtils {
	
	private static final String YUI_PATH = "http://yui.yahooapis.com"
	private static final String LATEST_VERSION = "2.5.2"
	
	public static String getResourcePath(String resourcePath, boolean remote){
		return getResourcePath(LATEST_VERSION, resourcePath, remote)
	}
	
	public static String getResourcePath(String version, String resourcePath, boolean remote){
		if(remote || ConfigurationHolder?.config?.richui?.serve?.resource?.files?.remote){
			return getYuiResourcePath(version)
		}
		
		return resourcePath + "/js/yui"
	}
	
	private static String getYuiResourcePath(){
		return getYuiResourcePath(LATEST_VERSION)
	}
	
	private static String getYuiResourcePath(String version){
		return "${YUI_PATH}/${version}/build"
	}
	
}