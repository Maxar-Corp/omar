/*==================================================
 *  Localization of Planning Labeller
 *==================================================
 */

Timeline.PlanningLabeller.labels["en"] = {
    dayPrefix:      "d",
    weekPrefix:     "w",
    monthPrefix:    "m",
    quarterPrefix:  "q",
    yearPrefix:     "y"
};