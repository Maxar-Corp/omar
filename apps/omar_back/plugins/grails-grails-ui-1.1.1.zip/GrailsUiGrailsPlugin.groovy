import org.springframework.beans.factory.config.MethodInvokingFactoryBean

class GrailsUiGrailsPlugin {
    def version = "1.1.1"
    def dependsOn = [
            core:"1.0 > *",
            bubbling:"2.1.1 > *",
            yui:"2.6.0 > *"
    ]
    
    def grailsVersion = "1.0 > *"

    def author = "Matthew Taylor"
    def authorEmail = "rhyolight@gmail.com"
    def title = "Grails UI"
    def description = '''
Provides a standard UI tag library for ajaxy widgets using YUI.
'''

    // URL to the plugin's documentation
    def documentation = "http://grails.org/plugins/grails-ui"

    def doWithSpring = {
        grailsUIConfig(MethodInvokingFactoryBean) {
            targetObject = new ConfigSlurper()
            targetMethod = 'parse'
            arguments = [application.classLoader.loadClass('GrailsUIConfig')]
        }
    }
   
    def doWithApplicationContext = { applicationContext ->
    }

    def doWithWebDescriptor = { xml ->
    }
	                                      
    def doWithDynamicMethods = { ctx ->
    }
	
    def onChange = { event ->
    }

    def onConfigChange = { event ->
    }
}
