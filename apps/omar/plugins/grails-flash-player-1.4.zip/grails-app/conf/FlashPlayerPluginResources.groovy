// Resource declarations for Resources plugin

modules = {

   'flashPlayer' {
      dependsOn 'swfobject'
      resource url: [plugin: 'flashPlayer', dir:'mediaplayer-5.8', file: "jwplayer.js"], disposition: 'head'
   }

}
