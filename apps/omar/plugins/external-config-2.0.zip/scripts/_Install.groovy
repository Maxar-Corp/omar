/**
 * Intentionally left blank since 2.0
 */