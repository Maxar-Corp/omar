// Resource declarations for Resources plugin

modules = {

   'swfobject' {
      resource url: [plugin: 'swfobject', dir:'js/swfobject', file: "swfobject.js"], disposition: 'head'
   }

}


