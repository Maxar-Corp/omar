package org.grails.plugins.swfobject

class SwfobjectTagLib {

   static namespace = 'swfobject'

   def resources = { attrs ->
      out << """
    	<script type="text/javascript" src="${g.resource(plugin: "swfobject", dir: 'js/swfobject', file: "swfobject.js").encodeAsHTML()}"></script>
    	"""
   }
       
   def expressInstall = { attrs ->
      out << """
    	<script type="text/javascript">
			swfobject.registerObject("${attrs.id ?: 'myId'}", "${attrs.version ?: '10.0.0'}", "${expressInstallSWF()}", "${attrs.flashvars ?: '{}'}, "${attrs.params ?: '{}'}, "${attrs.attributes ?: '{}'}"}");
		</script>
    	"""
   }
   
   def embedSWF = { attrs ->
      out << """
    	<script type="text/javascript">
			swfobject.embedSWF("${attrs.swf}, "${attrs.id ?: 'myId'}", "${attrs.width ?: '300'}", "${attrs.height ?: '240'}", "${attrs.version ?: '10.0.0'}");
    	</script>
    	"""
   }   
   
   def registerObject = { attrs ->
      out << """
    	<script type="text/javascript">
			swfobject.registerObject("${attrs.id ?: 'myId'}", "${expressInstallSWF()}");
    	</script>
    	"""
   }
   
   def expressInstallSWF = { attrs ->
      out << g.resource(plugin: "swfobject", dir: 'js/swfobject', file: "expressInstall.swf").encodeAsHTML()
   }
}
