class BrowserDetectionGrailsPlugin {
    // the plugin version
    def version = "0.1"
    // the version or versions of Grails the plugin is designed for
    def grailsVersion = "1.0 > *"
    // the other plugins this plugin depends on
    def dependsOn = [:]
    // resources that are excluded from plugin packaging
    def pluginExcludes = [
            "grails-app/views/error.gsp",
            "grails-app/controllers/org/geeks/browserdetection/TestController.groovy",
            "grails-app/views/index.gsp"
    ]

    // TODO Fill in these fields
    def author = "Kevin M. Gill, Edvinas Bartkus"
    def authorEmail = "kevin@wthr.us, edvinas@geeks.lt"
    def title = "Browser detection"
    def description = '''\\
This plugin provides service and tag library for browser detection. You can know what is the browser, version, operating system and language specified in request headers.
'''
    // URL to the plugin's documentation
    def documentation = "http://grails.org/plugin/browser-detection"
}
