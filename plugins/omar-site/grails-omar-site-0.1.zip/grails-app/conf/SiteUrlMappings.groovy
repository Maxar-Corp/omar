class SiteUrlMappings {

	static mappings = {
      "/ogc/wms**"(controller:"ogcExtend", action:"wmsFilter")
	}
}
