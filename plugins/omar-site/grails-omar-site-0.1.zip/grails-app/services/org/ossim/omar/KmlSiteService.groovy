package org.ossim.omar

class KmlSiteService{

    static transactional = true

    def myCreateImages(List<org.ossim.omar.RasterEntry> rasterEntries,
                                                Map wmsParams,
                                                Map params)
    {
      println "DOING MY SITE SERVICE CALL"
    }
}
