import org.codehaus.groovy.grails.commons.GrailsClassUtils as GCU

Ant.property(environment: "env")

grailsHome = Ant.project.properties."environment.GRAILS_HOME"

target('default': "The description of the script goes here!") {
  doStuff()
}

target(doStuff: "The implementation task") {

  def config = new ConfigSlurper(grailsEnv).parse(new File("${basedir}/grails-app/conf/DataSource.groovy").toURL())

  /*
  println "${config.dataSource.driverClassName}"
  println "${config.dataSource.username}"
  println "${config.dataSource.password}"
  println "${config.dataSource.url}"
  */

  def sql = Sql.newInstance(
      config.dataSource.url,
      config.dataSource.username,
      config.dataSource.password,
      config.dataSource.driverClassName
  )

  Ant.input(addProperty: "table.name", message: "Please enter the table name:")
  def tableName = Ant.antProject.properties."table.name"

  Ant.input(addProperty: "column.name", message: "Please enter the column name:")
  def columnName = Ant.antProject.properties."column.name"

  Ant.input(addProperty: "srid.name", message: "Please enter the srid:")
  def srid = Ant.antProject.properties."srid.name".toInteger()

  Ant.input(addProperty: "type.name", message: "Please enter the type name:")
  def typeName = Ant.antProject.properties."type.name"

  Ant.input(addProperty: "dimension.num", message: "Please enter the number of dimensions:")
  def dimenions = Ant.antProject.properties."dimension.num".toInteger()

  sql.execute("ALTER TABLE ${tableName} DROP COLUMN ${columnName};")

  sql.execute("""
  SELECT AddGeometryColumn( ${tableName}, ${columnName}, ${srid}, ${typeName}, ${dimenions} );
  """)

  sql.execute("""
  CREATE INDEX  ${tableName}_${columnName}_idx ON ${tableName} USING GIST ( ${columnName} GIST_GEOMETRY_OPS );
  """
  )

  sql.execute("VACUUM ANALYZE ${tableName} (${columnName} );")

  sql.close()
}