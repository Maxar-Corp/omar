package org.ossim.omar


class SuperoverlayJob {
  def timeout = 5000l // execute job once in 5 seconds
  //def startDelay = 60000 // delay for about 60 seconds before starting
  def startDelay = 4000 // delay for about 60 seconds before starting
  def sessionFactory
  def propertyInstanceMap = org.codehaus.groovy.grails.plugins.DomainClassGrailsPlugin.PROPERTY_INSTANCE_MAP

  def execute() {
	  println  "EXECUTING SUPEROVERLAY JOB"
  
/*
    def query = {
      eq("status", "ready")
      maxResults(20)
    }

    def result = SuperoverlayQueue.createCriteria().list(query)
    def count = 0
      result.each{record ->
        ++count;
        if ((count % 100) == 0)
        {
          cleanUpGorm()
        }
        def file   = record.file
		
        SuperoverlayQueue.withTransaction{
          record.status = "submitted"
          record.save(flush:true)
        }
       // DataManagerJob.triggerNow([file:file])
      }
      result.clear()
      result = DataManagerQueueItem.createCriteria().list(query)
      */
  }
  def cleanUpGorm()
  {
      def session = sessionFactory.currentSession
      session.flush()
      session.clear()
      propertyInstanceMap.get().clear()
  }
}
