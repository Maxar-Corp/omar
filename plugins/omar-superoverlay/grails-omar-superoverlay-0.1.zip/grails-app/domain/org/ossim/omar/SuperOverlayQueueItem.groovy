package org.ossim.omar

import java.util.Date;

class SuperOverlayQueueItem {

  String indexId
  Date   dateCreated
  Date   startTime = null
  Date   endTime   = null
  String action = "create"
  double priority = 0
  String status = "ready"
  
  static constraints = {
    indexId(nullable:false)
    dateCreated(nullable:true)
    startTime(nullable:true)
    endTime(nullable:true)
    baseDir(nullable:true)
    dataManagerAction(nullable:false)
    priority(nullable:false)
    status(nullable:false)
  }
}
