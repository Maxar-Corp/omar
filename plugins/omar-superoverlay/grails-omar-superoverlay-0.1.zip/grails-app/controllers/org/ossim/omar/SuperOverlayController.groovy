package org.ossim.omar
//import java.util.Date;

//import org.ossim.omar.SuperOverlayQueueItem
class SuperOverlayController {

    def index = { render "HELLO THERE!!!!!!"}
	def create =
	{
		println params 
		/*
		println params 
		if(params.id)
		{
			println "creating queue item"
		    //def rasterEntry = RasterEntry.createCriteria().getByIndexId(params.id)
			//if(rasterEntry)
			//{
 			    //println "creating queue item"
		        def queueItem = new SuperOverlayQueueItem()
			    queueItem.indexId = rasterEntry.indexId;
				queueItem.dateCreate = new Date()
                SuperOverlayQueueItem.withTransaction()
			    {
					if(queueItem.save(flush:true))
					{
						println "SAVED!!!!!"
					}
					else
					{
						println "NOT SAVED!!!"
					}
		      	}
			//}
		}
		*/
		null
	}
}
